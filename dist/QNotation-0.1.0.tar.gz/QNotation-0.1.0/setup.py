from setuptools import setup

setup(
    name='QNotation',
    version='0.1.0',
    description='A visual and interactive tool that supports the \
    learning of circuit, Dirac, and matrix notation within the context of Quantum Computing.',
    author='Samantha Norrie',
    author_email='https://github.com/Samantha-norrie/QNotation',
    packages=['qnotation'],
    install_requires=[
        # List your package dependencies here
        'reacton',
        'matplotlib',
        'qiskit',
        'numpy'
    ],
)